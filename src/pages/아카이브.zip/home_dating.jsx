import { useState } from "react";
import styled from "styled-components";

const Home = () => {
  const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]; // 요일 데이터
  const today = days[new Date().getDate()];
  const [selectedDay, setSelectedDay] = useState(today); // 선택된 날짜 상태

  return (
    <NewGrid>
      {days.map((day, index) => (
        <DayBox
          key={index}
          isSelected={selectedDay === day} // 선택 여부를 prop으로 전달
          onClick={() => setSelectedDay(day)} // 클릭 시 상태 업데이트
        >
          {day}
        </DayBox>
      ))}
    </NewGrid>
  );
};

// Grid 컨테이너 스타일
const NewGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(7, 1fr); /* 7개의 동일한 열 */
  gap: 10px;
  width: 100%;
  margin-top: 20px;
`;

// 날짜 박스 스타일
const DayBox = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: ${(props) =>
    props.isSelected ? "#50C878" : "#f5f5f5"}; /* 선택 여부에 따라 색 변경 */
  color: ${(props) =>
    props.isSelected ? "#fff" : "#333"}; /* 텍스트 색상 변경 */
  border-radius: 10px;
  font-size: 14px;
  font-weight: bold;
  height: 80px;
  cursor: pointer;
  transition: background-color 0.3s ease, color 0.3s ease; /* 애니메이션 추가 */

  &:hover {
    background-color: ${(props) =>
      props.isSelected ? "#45A167" : "#e0e0e0"}; /* 호버 효과 */
  }
`;

export default Home;
